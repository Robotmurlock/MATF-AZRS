#include <iostream>
#include <vector>
#include <fstream>

std::vector<int> load(std::istream& input)
{
    std::vector<int> v;
    int value;
    while(input >> value)
        v.push_back(value);
    return v;
}

void store(const std::vector<int>& v, std::ostream& output)
{
    for(int value: v)
        output << value << " ";
}

std::vector<int> drop_duplicates(const std::vector<int>& v)
{
    unsigned n = v.size();

    std::vector<int> result;
    for(int i=0; i<n; i++)
    {
        bool add = true;
        for(int j=0; j<i-1; j++)
        {
            if(v[i] == v[j])
            {
                add = false;
                break;
            }
        }
        if(add)
            result.push_back(v[i]);
    }
    return result;
}

int main()
{
    // test load
    std::ifstream input("input.txt");
	auto v = load(input);

    v = drop_duplicates(v);

    // test store
    std::ofstream output("output.txt");
    store(v, output);
    return 0;
}
